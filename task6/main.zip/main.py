import time


# A class to represent a graph object
class Graph:
    # Constructor
    def __init__(self, n,colors,left_children,right_children):
 
        # A list of lists to represent an adjacency list
        self.adjList = colors
        self.left    = left_children
        self.right   = right_children
        self.w = 0
        self.b = 0
        self.ww = 0
        self.bb = 0
    
    def count(self,head):
        if head== None :
            return 0
        else:
            return 1 + self.count(self.left[head]) + self.count(self.right[head])
    def countWhite(self,head):
        if head==None:
            return 0
        else:
            if self.adjList[head] == 0:
                return 1 + self.countWhite(self.left[head]) + self.countWhite(self.right[head]) 
            else:
                return 0 + self.countWhite(self.left[head]) + self.countWhite(self.right[head]) 
    def countBlack(self,head):
        if head==None:
            return 0
        else:
            if self.adjList[head] == 1:
                return 1 + self.countBlack(self.left[head]) + self.countBlack(self.right[head]) 
            else:
                return 0 + self.countBlack(self.left[head]) + self.countBlack(self.right[head]) 
     

if __name__ == '__main__':
   
    
    # input_list = [int(val)for val in input().split(' ')]
    n = int(input())

    list_of_colors = [int(color) for color in input().split(' ')]
    left_children  = n*[None]
    right_children = n*[None]

    
    for i in range(n-1):
        edge = [int(val) for val in input().split(' ')]
        if edge[2] == 0:
            left_children[edge[0]] = edge[1]
        if edge[2] == 1:
            right_children[edge[0]] = edge[1]

    start_time = time.time()
    graph = Graph(n,list_of_colors,left_children,right_children) 

    L = 0
    E = 0
    R = 0 

    for i in range(n):
        w = graph.countWhite(left_children[i])
        ww = graph.countWhite(right_children[i])
        b = graph.countBlack(left_children[i])
        bb = graph.countBlack(right_children[i])

        if b !=0 and bb!=0 and w!=0 and ww!=0:
            if w/b > ww/bb:  L+=1
            if w/b == ww/bb: E+=1
            if w/b < ww/bb:  R+=1


    output = ''
    output+= str(L)
    output+= ' '
    output+= str(E)
    output+= ' '
    output+= str(R)
    print(output)    

    # print("--- %s seconds ---" % (time.time() - start_time))