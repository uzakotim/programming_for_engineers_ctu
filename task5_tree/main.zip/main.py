# import time

# input_list = [
#     'AL',
#     'AR',
#     'C0',
#     'CL',
#     'CR',
#     'D',
#     'M',
#     'RK',
#     'RSR']



#-----------------------------
#           NODE
#-----------------------------
class Node:
    def __init__(self,key,depth,SR,Parent):
        self.left = None
        self.right = None
        self.parent = Parent
        self.tree = None
        self.depth = depth

        self.key = key
        self.SR  = SR
        self.SK  = None
        self.CTN = 0
        self.COL = 0



#-----------------------------
#         BINARY TREE
#-----------------------------
class Tree:
    def __init__(self,key,depth,SR):
        self.root = Node(key,depth,SR,None)
        self.maximal = 0
    
    def rndTree(self, node, depth):
        if depth<=0: return node
        if node.SR < input_list[2] or node.depth == input_list[5]:
            node.left = None
            node.right = None
            return node

        if input_list[2] <= node.SR and node.SR<input_list[3]:
            childNodeLeft   = Node ((input_list[0]*(node.key+1))%input_list[6],(node.depth + 1),(node.SR*input_list[0])%input_list[6],node)
            node.left = self.rndTree(childNodeLeft, depth-1)
            node.right = None
            return node
        if input_list[3] <= node.SR and node.SR < input_list[4]:
            node.left = None
            childNodeRight  = Node ((input_list[1]*(node.key+2))%input_list[6],(node.depth + 1),(node.SR*input_list[1])%input_list[6],node)
            node.right = self.rndTree(childNodeRight, depth-1)
            return node
        if input_list[4] <= node.SR and node.SR < input_list[6]:
            childNodeLeft   = Node ((input_list[0]*(node.key+1))%input_list[6],(node.depth + 1),(node.SR*input_list[0])%input_list[6],node)
            childNodeRight  = Node ((input_list[1]*(node.key+2))%input_list[6],(node.depth + 1),(node.SR*input_list[1])%input_list[6],node)
            node.left = self.rndTree(childNodeLeft,depth-1) 
            node.right = self.rndTree(childNodeRight,depth-1)
            return node
    # TASK 1
    def sumCosts(self,node):
        if node == None: return 0
        return node.key*(node.depth+1) + self.sumCosts(node.left) + self.sumCosts(node.right)
    
   
    # TASK 2
    def sumKeys(self,node):
        if node == None: return 0
        node.SK = node.key + self.sumKeys(node.left) + self.sumKeys(node.right)
        return node.SK

    def disbalance(self,node):  
        if node == None or (node.left == None and node.right==None): return 0
        if node.left == None:
            one = 0
        else:
            one = node.left.SK
        if node.right == None:
            two = 0
        else:
            two = node.right.SK
        if one> two:
            return one - two + self.disbalance(node.left) + self.disbalance(node.right)
        else:
            return two - one + self.disbalance(node.left) + self.disbalance(node.right)
    # TASK 3

    def countTwoNodes(self,node):
        if node == None: return 0
        if (node.left != None and node.right != None):
            node.CTN += 1 + self.countTwoNodes(node.left) + self.countTwoNodes(node.right)
            return node.CTN
        else:
            node.CTN += 0 + self.countTwoNodes(node.left) + self.countTwoNodes(node.right)
            return node.CTN

    def isTwoBalanced(self,node):
        if node.left == None and node.right == None:return True
        if node.left != None and node.right == None:
            if node.left.CTN == 0: return True
            else: return False
        if node.left == None and node.right != None:
            if node.right.CTN == 0:return True
            else: return False

        if (node.left.CTN == node.right.CTN): return True
        else: return False

    def sumKeys2Balanced(self,node):
        if node == None: return 0
        if self.isTwoBalanced(node): return node.key + self.sumKeys2Balanced(node.left) + self.sumKeys2Balanced(node.right)
        else: return 0 + self.sumKeys2Balanced(node.left) + self.sumKeys2Balanced(node.right)
    # Task 4
    def isSibling(self,nodeOne,nodeTwo):
        if nodeOne == None or nodeTwo==None:  return False
        if nodeOne.parent == nodeTwo.parent:  return True
        if nodeOne.parent != nodeTwo.parent:  return False         

    def isParitySibling(self,nodeOne,nodeTwo):
        if self.isSibling(nodeOne,nodeTwo): 
            if (nodeOne.key%2) == (nodeTwo.key%2): return True
        else: return False
    def countSiblings(self,node):
        if node == None: return 0
        
        if self.isParitySibling(node.left,node.right): return 1+ self.countSiblings(node.left) + self.countSiblings(node.right)
        else: return 0+ self.countSiblings(node.left) + self.countSiblings(node.right)

       

    # TASK 5
    def isMinimal(self,node, key):
        if node ==None :    return True
        if node.key >= key: return True and (self.isMinimal(node.left,key) and self.isMinimal(node.right,key))
        if node.key < key:  return False and (self.isMinimal(node.left,key) and self.isMinimal(node.right,key))

    def sumKeysMinimal(self,node):
        if node == None: return 0
        if self.isMinimal(node,node.key):       return node.key + self.sumKeysMinimal(node.left) + self.sumKeysMinimal(node.right)
        if not self.isMinimal(node,node.key):   return 0 + self.sumKeysMinimal(node.left) + self.sumKeysMinimal(node.right)
        
    # TASK 6
    def isLeaf(self,node):
        if (node.left==None and node.right==None):
            return True
        else:
            return False

    def isWeakly(self,node,key):
        result = True
        if node ==None : 
            return True
        if node.left == None and node.right == None:
            if node.key <= key:
                result = True 
            else:
                result = False
        if node.left == None and node.right!=None:
            return result and self.isWeakly(node.right,key)
        if node.right == None and node.left!=None:
            return result and self.isWeakly(node.left,key)
        if node.right!=None and node.left!= None:
            return result and (self.isWeakly(node.left,key) and self.isWeakly(node.right,key))

    def countWeakly(self,node):
        if node == None: return 0
        if self.isWeakly(node,node.key) and not self.isLeaf(node):
            return 1 + self.countWeakly(node.left) + self.countWeakly(node.right)
        else:
            return 0 + self.countWeakly(node.left) + self.countWeakly(node.right)
        

    # TASK 7

    def countOnlyLeft(self,node):
        if node == None: return 0
        if (node.left != None and node.right == None):
            node.COL = 1 + self.countOnlyLeft(node.left) + self.countOnlyLeft(node.right)
            return node.COL
        elif (node.left == None and node.right == None):
            node.COL = 0 + self.countOnlyLeft(node.left) + self.countOnlyLeft(node.right)
            return node.COL
        elif (node.left == None and node.right != None):
            node.COL = -10000000 + self.countOnlyLeft(node.left) + self.countOnlyLeft(node.right)
            return node.COL
        else:
            node.COL = 0 + self.countOnlyLeft(node.left) + self.countOnlyLeft(node.right)
            return node.COL
    
    def countL1(self,node):
        if node == None: return 0
        if (node.COL>0):
            return 1 + self.countL1(node.left) + self.countL1(node.right)
        else:
            return 0 + self.countL1(node.left) + self.countL1(node.right)
    
    # TASK 8     

    def customFindPathes(self,node,path):
        if node == None : return
        path.append(node.key)
        maximal_value = self.maximal
        current_sum = path[0]

        for i in range(len(path)-1):
            if path[i]<=path[i+1]:
                current_sum += path[i+1]
            else:
                if current_sum>=maximal_value:
                    self.maximal = current_sum
                current_sum = 0 + path[i+1]
        
        if current_sum>=maximal_value:
            self.maximal = current_sum
        
        self.customFindPathes(node.left,path)
        self.customFindPathes(node.right,path)
        path.pop()
        


if __name__ == '__main__':
   
    # start_time = time.time()
    input_list = [int(val)for val in input().split(' ')]

    t = Tree(input_list[7],0,input_list[8])    
    t.rndTree(t.root, input_list[5])
    output = ''
    output+= str(t.sumCosts(t.root))
    output+= '\n'
    
    t.sumKeys(t.root)
    output+= str(t.disbalance(t.root))
    output+= '\n'
    
    t.countTwoNodes(t.root)
    output+= str(t.sumKeys2Balanced(t.root))
    output+= '\n'
    
    output += str(t.countSiblings(t.root))
    output+= '\n'
    
    output += str(t.sumKeysMinimal(t.root))
    output+= '\n'
    
    output += str(t.countWeakly(t.root))
    output+= '\n'
    
    t.countOnlyLeft(t.root)
    output += str(t.countL1(t.root))
    output+= '\n'
    
    t.customFindPathes(t.root,[])
    output+=str(t.maximal)
    print(output)
    # print("--- %s seconds ---" % (time.time() - start_time))